#工程绝对路径
project_path=$(pwd)
echo "-----> 工程路径：${project_path}"

#工程名称
project_name=$(ls | grep xcodeproj | awk -F.xcodeproj '{print $1}')
echo "-----> 工程文件名称：${project_name}"

#Info.plist路径
project_infoplist_path=${project_path}/${project_name}/Info.plist
echo "-----> Info.plist路径：${project_infoplist_path}"

#APP名称
/usr/libexec/PlistBuddy -c "set CFBundleDisplayName 招联金融MUAPP" ${project_infoplist_path}
#修改bundleID
/usr/libexec/PlistBuddy -c "set CFBundleIdentifier com.MUAPP.com" ${project_infoplist_path}
#修改版本号
/usr/libexec/PlistBuddy -c "set CFBundleShortVersionString 2.0.0" ${project_infoplist_path}




