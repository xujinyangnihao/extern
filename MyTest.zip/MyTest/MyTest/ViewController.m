//
//  ViewController.m
//  MyTest
//
//  Created by xjy on 2022/6/23.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"xxxx");
    
    
    void(^block1)(void);
    
//    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
//    dict[@"block"] = block1;
////    NSMutableDictionary *dict = @{@"xx": block1};
//    NSLog(@"%@", dict);
//    
//    NSMutableArray *arr = [NSMutableArray array];
//    [arr addObject:dict];
//    NSLog(@"%@", arr);
//    
//    [arr addObject:block1];
//    NSLog(@"%@", arr);
}


@end
