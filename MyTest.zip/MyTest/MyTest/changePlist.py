# 导入python内置的os模块和sys模块
import os
import sys
from biplist import *


# 程序入口
if __name__ == "__main__":
    # 获取APP名称
    pre = input("请输入APP名称:")
    name  = "%s"%pre
    plist = readPlist("info.plist");
    BundleDisplayName = plist['CFBundleDisplayName'];
    print (BundleDisplayName)
    plist['CFBundleDisplayName'] = name
    BundleDisplayName = plist['CFBundleDisplayName'];
    print (BundleDisplayName)
    writePlist(plist,"info.plist")

    

    



